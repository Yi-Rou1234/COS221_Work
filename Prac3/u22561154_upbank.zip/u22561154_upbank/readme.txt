u22561154
TASK 7:

mysql -u root -p
mysql> CREATE DATABASE u22561154_upbank;
mysql -u root -p u22561154_upbank < mysqldump.sql